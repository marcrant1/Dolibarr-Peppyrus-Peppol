<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation - Dolibarr Peppol Export</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: white; border-radius: 10px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); overflow: hidden; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
        .header h1 { font-size: 32px; margin-bottom: 10px; }
        .header p { opacity: 0.9; }
        .content { padding: 40px; }
        .step { background: #f8f9fa; border-left: 4px solid #667eea; padding: 20px; margin: 20px 0; border-radius: 5px; }
        .step h2 { color: #667eea; margin-bottom: 15px; font-size: 20px; }
        .step ol { margin-left: 20px; }
        .step li { margin: 10px 0; line-height: 1.6; }
        .warning { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 5px; }
        .warning strong { color: #856404; }
        .success { background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 5px; }
        .success strong { color: #155724; }
        .error { background: #f8d7da; border-left: 4px solid #dc3545; padding: 15px; margin: 20px 0; border-radius: 5px; }
        .error strong { color: #721c24; }
        .button { display: inline-block; background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; transition: all 0.3s; }
        .button:hover { background: #5568d3; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3); }
        .button-success { background: #28a745; }
        .button-success:hover { background: #218838; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        code { background: #f8f9fa; padding: 2px 6px; border-radius: 3px; font-family: 'Courier New', monospace; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; border-top: 1px solid #dee2e6; }
        .progress { background: #e9ecef; height: 30px; border-radius: 15px; overflow: hidden; margin: 20px 0; }
        .progress-bar { background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); height: 100%; text-align: center; line-height: 30px; color: white; font-weight: bold; transition: width 0.5s; }
        .check-item { padding: 10px; margin: 5px 0; border-radius: 5px; display: flex; align-items: center; }
        .check-item.ok { background: #d4edda; }
        .check-item.error { background: #f8d7da; }
        .check-item::before { content: '✅'; margin-right: 10px; }
        .check-item.error::before { content: '❌'; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 Installation - Peppol Export</h1>
            <p>Installateur automatique pour Dolibarr</p>
        </div>
        
        <div class="content">
            <?php
            error_reporting(E_ALL);
            ini_set('display_errors', 1);
            
            $step = isset($_GET['step']) ? $_GET['step'] : 1;
            $github_url = 'https://github.com/votre-username/dolibarr-peppol-export/archive/refs/heads/main.zip';
            $install_dir = __DIR__ . '/peppolexport/';
            
            // Fonctions utilitaires
            function checkRequirements() {
                $checks = [];
                $checks['PHP Version'] = version_compare(PHP_VERSION, '7.0.0', '>=');
                $checks['Extension curl'] = extension_loaded('curl');
                $checks['Extension json'] = extension_loaded('json');
                $checks['Extension xml'] = extension_loaded('xml');
                $checks['Extension dom'] = extension_loaded('dom');
                $checks['Extension openssl'] = extension_loaded('openssl');
                $checks['Write permission'] = is_writable(__DIR__);
                return $checks;
            }
            
            function downloadModule($url, $destination) {
                $ch = curl_init($url);
                $fp = fopen($destination, 'w');
                curl_setopt($ch, CURLOPT_FILE, $fp);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 300);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $result = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                fclose($fp);
                return $httpCode === 200 && $result !== false;
            }
            
            // Étape 1 : Vérification des prérequis
            if ($step == 1) {
                echo '<h2>📋 Étape 1/4 : Vérification des prérequis</h2>';
                echo '<div class="progress"><div class="progress-bar" style="width: 25%">25%</div></div>';
                
                $checks = checkRequirements();
                $allOk = true;
                
                echo '<div class="step">';
                echo '<h2>🔍 Vérification du système</h2>';
                foreach ($checks as $name => $status) {
                    $class = $status ? 'ok' : 'error';
                    echo '<div class="check-item ' . $class . '">' . $name . '</div>';
                    if (!$status) $allOk = false;
                }
                echo '</div>';
                
                if ($allOk) {
                    echo '<div class="success">';
                    echo '<strong>✅ Tous les prérequis sont remplis !</strong><br>';
                    echo 'Vous pouvez continuer l\'installation.';
                    echo '</div>';
                    echo '<p style="text-align: center; margin-top: 30px;">';
                    echo '<a href="?step=2" class="button">Continuer →</a>';
                    echo '</p>';
                } else {
                    echo '<div class="error">';
                    echo '<strong>❌ Certains prérequis ne sont pas remplis</strong><br>';
                    echo 'Veuillez corriger les problèmes avant de continuer.<br><br>';
                    echo '<strong>Solutions :</strong><br>';
                    echo '• Extensions PHP manquantes : <code>sudo apt-get install php-curl php-xml php-json</code><br>';
                    echo '• Permissions : <code>sudo chmod 755 ' . __DIR__ . '</code>';
                    echo '</div>';
                }
            }
            
            // Étape 2 : Téléchargement
            elseif ($step == 2) {
                echo '<h2>📥 Étape 2/4 : Téléchargement du module</h2>';
                echo '<div class="progress"><div class="progress-bar" style="width: 50%">50%</div></div>';
                
                $zipFile = __DIR__ . '/peppolexport.zip';
                
                echo '<div class="step">';
                echo '<h2>⬇️ Téléchargement depuis GitHub</h2>';
                echo '<p>Source : <code>' . $github_url . '</code></p>';
                echo '<p>Destination : <code>' . $zipFile . '</code></p>';
                echo '</div>';
                
                echo '<p>Téléchargement en cours...</p>';
                flush();
                
                if (downloadModule($github_url, $zipFile)) {
                    echo '<div class="success">';
                    echo '<strong>✅ Module téléchargé avec succès !</strong><br>';
                    echo 'Taille : ' . number_format(filesize($zipFile) / 1024, 2) . ' KB';
                    echo '</div>';
                    echo '<p style="text-align: center; margin-top: 30px;">';
                    echo '<a href="?step=3" class="button">Continuer →</a>';
                    echo '</p>';
                } else {
                    echo '<div class="error">';
                    echo '<strong>❌ Erreur lors du téléchargement</strong><br>';
                    echo 'Impossible de télécharger le module depuis GitHub.<br><br>';
                    echo '<strong>Solutions :</strong><br>';
                    echo '• Vérifiez votre connexion internet<br>';
                    echo '• Téléchargez manuellement depuis <a href="' . $github_url . '" target="_blank">GitHub</a><br>';
                    echo '• Ou suivez le <a href="https://github.com/votre-username/dolibarr-peppol-export#installation" target="_blank">guide d\'installation manuel</a>';
                    echo '</div>';
                }
            }
            
            // Étape 3 : Extraction
            elseif ($step == 3) {
                echo '<h2>📦 Étape 3/4 : Extraction des fichiers</h2>';
                echo '<div class="progress"><div class="progress-bar" style="width: 75%">75%</div></div>';
                
                $zipFile = __DIR__ . '/peppolexport.zip';
                
                if (!file_exists($zipFile)) {
                    echo '<div class="error"><strong>❌ Fichier ZIP non trouvé</strong><br>';
                    echo 'Retournez à l\'étape précédente.</div>';
                    echo '<p style="text-align: center;"><a href="?step=2" class="button">← Retour</a></p>';
                } else {
                    echo '<div class="step">';
                    echo '<h2>📂 Extraction</h2>';
                    echo '<p>Extraction en cours...</p>';
                    flush();
                    
                    $zip = new ZipArchive;
                    if ($zip->open($zipFile) === TRUE) {
                        // Extraire dans un dossier temporaire
                        $tempDir = __DIR__ . '/temp_extract/';
                        $zip->extractTo($tempDir);
                        $zip->close();
                        
                        // Renommer le dossier extrait
                        $extractedDir = $tempDir . 'dolibarr-peppol-export-main/';
                        if (is_dir($extractedDir)) {
                            rename($extractedDir, $install_dir);
                            rmdir($tempDir);
                        }
                        
                        // Définir les permissions
                        chmod($install_dir, 0755);
                        
                        // Supprimer le ZIP
                        unlink($zipFile);
                        
                        echo '</div>';
                        echo '<div class="success">';
                        echo '<strong>✅ Fichiers extraits avec succès !</strong><br>';
                        echo 'Emplacement : <code>' . $install_dir . '</code>';
                        echo '</div>';
                        echo '<p style="text-align: center; margin-top: 30px;">';
                        echo '<a href="?step=4" class="button">Continuer →</a>';
                        echo '</p>';
                    } else {
                        echo '</div>';
                        echo '<div class="error">';
                        echo '<strong>❌ Erreur lors de l\'extraction</strong><br>';
                        echo 'Impossible d\'extraire le fichier ZIP.';
                        echo '</div>';
                    }
                }
            }
            
            // Étape 4 : Finalisation
            elseif ($step == 4) {
                echo '<h2>✅ Étape 4/4 : Installation terminée !</h2>';
                echo '<div class="progress"><div class="progress-bar" style="width: 100%">100%</div></div>';
                
                echo '<div class="success">';
                echo '<h2 style="color: #155724;">🎉 Installation réussie !</h2>';
                echo '<p>Le module Peppol Export a été installé avec succès dans :</p>';
                echo '<pre>' . $install_dir . '</pre>';
                echo '</div>';
                
                echo '<div class="step">';
                echo '<h2>📝 Prochaines étapes</h2>';
                echo '<ol>';
                echo '<li><strong>Supprimez ce fichier d\'installation</strong> pour des raisons de sécurité :<br>';
                echo '<code>rm ' . __FILE__ . '</code></li>';
                echo '<li><strong>Activez le module</strong> dans Dolibarr :<br>';
                echo 'Configuration → Modules/Applications → Rechercher "Peppol Export" → Activer</li>';
                echo '<li><strong>Configurez le module</strong> :<br>';
                echo 'Configuration → Modules → Peppol Export → ⚙️ Configuration</li>';
                echo '<li><strong>Lisez la documentation</strong> :<br>';
                echo '<a href="peppolexport/README.md" target="_blank">README.md</a></li>';
                echo '</ol>';
                echo '</div>';
                
                echo '<div class="warning">';
                echo '<strong>⚠️ Important - Sécurité</strong><br>';
                echo 'Pour des raisons de sécurité, supprimez ce fichier immédiatement :<br>';
                echo '<pre>rm ' . basename(__FILE__) . '</pre>';
                echo '</div>';
                
                echo '<p style="text-align: center; margin-top: 30px;">';
                echo '<a href="../../admin/modules.php" class="button button-success">Aller vers les modules →</a>';
                echo '</p>';
            }
            ?>
        </div>
        
        <div class="footer">
            <p><strong>Dolibarr Peppol Export</strong> - Module gratuit sous licence GPL v3</p>
            <p style="margin-top: 10px;">
                <a href="https://github.com/votre-username/dolibarr-peppol-export" target="_blank">GitHub</a> •
                <a href="https://github.com/votre-username/dolibarr-peppol-export/blob/main/docs/installation.md" target="_blank">Documentation</a> •
                <a href="https://github.com/votre-username/dolibarr-peppol-export/issues" target="_blank">Support</a>
            </p>
        </div>
    </div>
</body>
</html>
