<?php
/**
 * Test de configuration Peppol
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

$main_path = '/home/one967telemarcrant1967/public_html/dolibarr-19.0.0/htdocs/main.inc.php';

if (!file_exists($main_path)) {
    die('ERROR: main.inc.php not found');
}

include $main_path;

if (!defined('DOL_DOCUMENT_ROOT')) {
    die('ERROR: Dolibarr not loaded');
}

echo "<html><body><pre>";
echo "=== TEST CONFIGURATION PEPPOL ===\n\n";

echo "1. Dolibarr chargé : OUI\n";
echo "2. DOL_DOCUMENT_ROOT : " . DOL_DOCUMENT_ROOT . "\n\n";

echo "3. Configuration Peppol Export :\n";
echo "   - Module activé : " . (!empty($conf->peppolexport->enabled) ? 'OUI' : 'NON') . "\n";
echo "   - API URL : " . (!empty($conf->global->PEPPOLEXPORT_API_URL) ? $conf->global->PEPPOLEXPORT_API_URL : 'NON CONFIGURÉ') . "\n";
echo "   - API KEY : " . (!empty($conf->global->PEPPOLEXPORT_API_KEY) ? 'CONFIGURÉ (' . strlen($conf->global->PEPPOLEXPORT_API_KEY) . ' caractères)' : 'NON CONFIGURÉ') . "\n";
echo "   - PEPPOL ID : " . (!empty($conf->global->PEPPOLEXPORT_PEPPOL_ID) ? $conf->global->PEPPOLEXPORT_PEPPOL_ID : 'NON CONFIGURÉ') . "\n\n";

echo "4. Test de récupération directe depuis la base :\n";
$sql = "SELECT name, value FROM " . MAIN_DB_PREFIX . "const WHERE name LIKE 'PEPPOLEXPORT%' ORDER BY name";
$resql = $db->query($sql);
if ($resql) {
    $num = $db->num_rows($resql);
    if ($num > 0) {
        while ($obj = $db->fetch_object($resql)) {
            echo "   - " . $obj->name . " = " . ($obj->name == 'PEPPOLEXPORT_API_KEY' ? '***MASQUÉ***' : $obj->value) . "\n";
        }
    } else {
        echo "   AUCUNE configuration trouvée en base !\n";
    }
} else {
    echo "   ERREUR SQL : " . $db->lasterror() . "\n";
}

echo "\n=================================\n";
echo "</pre></body></html>";
?>